package com.simplehindibookmaker.app

import android.app.Activity
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.webkit.WebView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfGenerator(private val activity: Activity, private val webView: WebView) {

    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        const val PAGE_WIDTH_MILS = 5500
        const val PAGE_HEIGHT_MILS = 8500
        const val MEDIA_SIZE_ID = "CUSTOM_5_5_X_8_5"
        const val MEDIA_SIZE_LABEL = "5.5 x 8.5 inches"
    }

    interface PdfCallback {
        fun onProgress(message: String)
        fun onSuccess(savedPath: String)
        fun onError(error: String)
    }

    fun generatePdf(documentName: String, callback: PdfCallback) {
        mainHandler.post {
            try {
                callback.onProgress("Preparing document layout (5.5 × 8.5 in)...")

                val mediaSize = PrintAttributes.MediaSize(
                    MEDIA_SIZE_ID,
                    MEDIA_SIZE_LABEL,
                    PAGE_WIDTH_MILS,
                    PAGE_HEIGHT_MILS
                )

                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(mediaSize)
                    .setResolution(PrintAttributes.Resolution("res_300", "300 DPI", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val cleanDocName = documentName.replace("[^a-zA-Z0-9_\\-]".toRegex(), "_")
                val finalFileName = "${cleanDocName}_${timestamp}.pdf"

                val tempFile = File(activity.cacheDir, "temp_print_$timestamp.pdf")
                if (tempFile.exists()) tempFile.delete()

                val pfd = ParcelFileDescriptor.open(
                    tempFile,
                    ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
                )

                val adapter = webView.createPrintDocumentAdapter(cleanDocName)
                val cancellationSignal = CancellationSignal()

                adapter.onLayout(
                    null,
                    printAttributes,
                    cancellationSignal,
                    object : PrintDocumentAdapter.LayoutResultCallback() {
                        override fun onLayoutFinished(info: android.print.PrintDocumentInfo?, changed: Boolean) {
                            super.onLayoutFinished(info, changed)
                            callback.onProgress("Writing vector PDF pages...")

                            adapter.onWrite(
                                arrayOf(PageRange.ALL_PAGES),
                                pfd,
                                cancellationSignal,
                                object : PrintDocumentAdapter.WriteResultCallback() {
                                    override fun onWriteFinished(pages: Array<out PageRange>?) {
                                        super.onWriteFinished(pages)
                                        try {
                                            pfd.close()
                                            callback.onProgress("Saving to Downloads...")
                                            val savedPath = FileUtils.savePdfToDownloads(activity, tempFile, finalFileName)
                                            tempFile.delete()
                                            mainHandler.post { callback.onSuccess(savedPath) }
                                        } catch (e: Exception) {
                                            pfd.close()
                                            tempFile.delete()
                                            mainHandler.post { callback.onError(e.message ?: "Failed to save PDF to storage") }
                                        }
                                    }

                                    override fun onWriteFailed(error: CharSequence?) {
                                        super.onWriteFailed(error)
                                        pfd.close()
                                        tempFile.delete()
                                        mainHandler.post { callback.onError(error?.toString() ?: "PDF writing failed") }
                                    }

                                    override fun onWriteCancelled() {
                                        super.onWriteCancelled()
                                        pfd.close()
                                        tempFile.delete()
                                        mainHandler.post { callback.onError("PDF generation cancelled") }
                                    }
                                }
                            )
                        }

                        override fun onLayoutFailed(error: CharSequence?) {
                            super.onLayoutFailed(error)
                            pfd.close()
                            tempFile.delete()
                            mainHandler.post { callback.onError(error?.toString() ?: "PDF layout failed") }
                        }

                        override fun onLayoutCancelled() {
                            super.onLayoutCancelled()
                            pfd.close()
                            tempFile.delete()
                            mainHandler.post { callback.onError("PDF layout cancelled") }
                        }
                    },
                    null
                )
            } catch (e: Exception) {
                callback.onError(e.message ?: "Failed to initiate PDF generation")
            }
        }
    }
}
