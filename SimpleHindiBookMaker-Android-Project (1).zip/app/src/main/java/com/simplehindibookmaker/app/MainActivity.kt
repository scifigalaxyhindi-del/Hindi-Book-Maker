package com.simplehindibookmaker.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressOverlay: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var pdfGenerator: PdfGenerator

    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (filePathCallback != null) {
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressOverlay = findViewById(R.id.progressOverlay)
        progressText = findViewById(R.id.progressText)

        pdfGenerator = PdfGenerator(this, webView)

        setupWebView()
        loadLocalEditor()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.addJavascriptInterface(AndroidPdfBridge(this), "AndroidPDF")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("file:///android_asset/")) {
                    return false
                }
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Cannot open link: $url", Toast.LENGTH_SHORT).show()
                }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }

                try {
                    fileChooserLauncher.launch(intent)
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    return false
                }
                return true
            }
        }
    }

    private fun loadLocalEditor() {
        webView.loadUrl("file:///android_asset/index.html")
    }

    fun generateFullBookPdf() {
        showProgress("Generating Complete Book PDF (5.5 × 8.5 in)...")
        webView.evaluateJavascript(
            "document.body.classList.remove('print-single-page'); document.querySelectorAll('.book-page').forEach(function(p){ p.classList.remove('print-active-page'); });",
            null
        )
        pdfGenerator.generatePdf("SimpleHindiBook_Complete", object : PdfGenerator.PdfCallback {
            override fun onProgress(message: String) { updateProgress(message) }
            override fun onSuccess(savedPath: String) {
                hideProgress()
                showResultDialog("Complete Book Exported", "PDF generated successfully\nLocation: $savedPath")
                notifyWebEditor(savedPath, true, null)
            }
            override fun onError(error: String) {
                hideProgress()
                Toast.makeText(this@MainActivity, "PDF Export Failed: $error", Toast.LENGTH_LONG).show()
                notifyWebEditor("", false, error)
            }
        })
    }

    fun generateCurrentPagePdf() {
        showProgress("Generating Current Page PDF (5.5 × 8.5 in)...")
        webView.evaluateJavascript(
            "document.body.classList.add('print-single-page'); document.querySelectorAll('.book-page').forEach(function(p){ if (p.classList.contains('active-page')) { p.classList.add('print-active-page'); } else { p.classList.remove('print-active-page'); } });",
            {
                pdfGenerator.generatePdf("SimpleHindiBook_CurrentPage", object : PdfGenerator.PdfCallback {
                    override fun onProgress(message: String) { updateProgress(message) }
                    override fun onSuccess(savedPath: String) {
                        restoreFullView()
                        hideProgress()
                        showResultDialog("Current Page Exported", "PDF generated successfully\nLocation: $savedPath")
                        notifyWebEditor(savedPath, true, null)
                    }
                    override fun onError(error: String) {
                        restoreFullView()
                        hideProgress()
                        Toast.makeText(this@MainActivity, "Current Page Export Failed: $error", Toast.LENGTH_LONG).show()
                        notifyWebEditor("", false, error)
                    }
                })
            }
        )
    }

    fun generateTestPdf() {
        showProgress("Running 5.5 × 8.5 in PDF Test (396 × 612 pt)...")
        pdfGenerator.generatePdf("SimpleHindiBook_Test", object : PdfGenerator.PdfCallback {
            override fun onProgress(message: String) { updateProgress(message) }
            override fun onSuccess(savedPath: String) {
                hideProgress()
                showResultDialog("PDF Test Completed", "PDF generated successfully\nLocation: $savedPath\nSize: 396 × 612 pt (5.5 × 8.5 in)")
                notifyWebEditor(savedPath, true, null)
            }
            override fun onError(error: String) {
                hideProgress()
                Toast.makeText(this@MainActivity, "Test PDF Failed: $error", Toast.LENGTH_LONG).show()
                notifyWebEditor("", false, error)
            }
        })
    }

    private fun restoreFullView() {
        webView.evaluateJavascript(
            "document.body.classList.remove('print-single-page'); document.querySelectorAll('.book-page').forEach(function(p){ p.classList.remove('print-active-page'); });",
            null
        )
    }

    private fun notifyWebEditor(filePath: String, success: Boolean, errorMsg: String?) {
        val js = "if (window.onPdfExportComplete) { window.onPdfExportComplete('$filePath', $success, ${if (errorMsg == null) "null" else "'$errorMsg'"}); }"
        webView.evaluateJavascript(js, null)
    }

    private fun showProgress(msg: String) {
        progressText.text = msg
        progressOverlay.visibility = View.VISIBLE
    }

    private fun updateProgress(msg: String) {
        runOnUiThread { progressText.text = msg }
    }

    private fun hideProgress() {
        progressOverlay.visibility = View.GONE
    }

    private fun showResultDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}
