package com.simplehindibookmaker.app

import android.webkit.JavascriptInterface

class AndroidPdfBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun exportFullBook() {
        activity.runOnUiThread {
            activity.generateFullBookPdf()
        }
    }

    @JavascriptInterface
    fun exportCurrentPage() {
        activity.runOnUiThread {
            activity.generateCurrentPagePdf()
        }
    }

    @JavascriptInterface
    fun testPdf() {
        activity.runOnUiThread {
            activity.generateTestPdf()
        }
    }
}
