# Keep JavaScript interface methods from being stripped
-keepclassmembers class com.simplehindibookmaker.app.AndroidPdfBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
